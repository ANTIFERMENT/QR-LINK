#!/usr/bin/env python3
"""Sign a QR LINK APK using one GitHub Actions secret containing a zipped signing identity.
The secret holds a Base64-encoded ZIP with qr-link-release.p12 and signing.json.
A certificate fingerprint embedded in UpdateManager.java prevents mismatched keys.
"""
import base64
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

root=Path(__file__).resolve().parents[1]
secret=os.environ.get('QR_LINK_SIGNING_BUNDLE', '').strip()
if not secret:
    raise SystemExit('Missing GitHub Actions Secret: QR_LINK_SIGNING_BUNDLE')
try:
    raw=base64.b64decode(secret,validate=True)
    if len(raw)>64*1024: raise ValueError('bundle unexpectedly large')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        config=json.loads(z.read('signing.json'))
        key_bytes=z.read('qr-link-release.p12')
except Exception as ex:
    raise SystemExit('Invalid signing bundle (must be Base64 ZIP with signing.json and qr-link-release.p12)') from ex

sdk=Path(os.environ['ANDROID_SDK_ROOT'])
buildtools=sdk/'build-tools'/'36.0.0'
zipalign=buildtools/'zipalign'
apksigner=buildtools/'apksigner'
source_dir=root/'app'/'build'/'outputs'/'apk'/'release'
apks=sorted(source_dir.glob('*.apk'))
if len(apks)!=1:
    raise SystemExit(f'Expected one unsigned release APK, found {len(apks)}')
output=root/'dist'/'QR-LINK.apk'
output.parent.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='qr-link-sign-') as dirname:
    work=Path(dirname)
    key=work/'qr-link-release.p12'
    key.write_bytes(key_bytes)
    key.chmod(0o600)
    cert=work/'release.cer'
    env=os.environ.copy()
    env['QR_LINK_KS_PASS']=config['keystore_password']
    env['QR_LINK_KEY_PASS']=config['key_password']
    subprocess.run(['keytool','-exportcert','-alias',config['alias'],
        '-keystore',str(key),'-storetype','PKCS12',
        '-storepass:env','QR_LINK_KS_PASS','-file',str(cert)],check=True,env=env,capture_output=True)
    actual=sha256(cert.read_bytes()).hexdigest().upper()
    expected=config['certificate_sha256'].upper()
    if actual!=expected: raise SystemExit('Signing key certificate mismatch with backup metadata')
    source=(root/'app/src/main/java/dev/xarkon/link/UpdateManager.java').read_text()
    match=re.search(r'TRUSTED_CERT_SHA256="([0-9A-F]{64})"',source)
    if not match or match.group(1)!=actual:
        raise SystemExit('The signing certificate does not match the immutable certificate pin in UpdateManager.java')
    aligned=work/'aligned.apk'
    subprocess.run([str(zipalign),'-f','-p','4',str(apks[0]),str(aligned)],check=True)
    subprocess.run([str(apksigner),'sign','--ks',str(key),
         '--ks-type','PKCS12','--ks-key-alias',config['alias'],
         '--ks-pass','env:QR_LINK_KS_PASS',
         '--key-pass','env:QR_LINK_KEY_PASS','--out',str(output),str(aligned)],
         check=True,env=env)
    subprocess.run([str(apksigner),'verify','--verbose','--print-certs',str(output)],check=True)
    subprocess.run([str(zipalign),'-c','-p','4',str(output)],check=True)
print('Release APK signed and certificate pin checked:',actual)
